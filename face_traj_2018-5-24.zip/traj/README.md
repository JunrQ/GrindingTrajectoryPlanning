#
include codes for tranforming homogeneous transform matrix to unit 
quaternion, unit quaternion to homogeneous transform matrix,
unit quaternion interplation, coordinate interplation.


# traj utils functions
use `rotm = quat2rotm(quat)`, and `quat = rotm2quat(rotm)` instead.
