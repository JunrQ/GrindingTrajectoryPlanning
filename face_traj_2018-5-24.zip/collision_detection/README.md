# Collision detection for my project
In order to avoid collision, we want to see if a particular point
is outside all the faces ()

## KD Tree


## ANN(Approximate Neareast Neighbor)