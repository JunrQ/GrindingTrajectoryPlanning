#
include codes for turning path to pose

# connectPaths

# path2Ts

# myInverse