%MYTRAVERSER solver for graph traveser problem, implemented by c++, with mex.
%
% [orderedPointsCloud, orderedPointsCloudIdx] = myTraverser(pointsCloud, pointsCloudIdx, method) given pointsClound in
% [m, 3] matrix, return ordered pointsCloud in [m, 3] matrix.
%
% - method
%
% Author::
% - JunrZhou