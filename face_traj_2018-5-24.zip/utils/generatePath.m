%GENERATEPATH generate path
%
% path = generatePath()